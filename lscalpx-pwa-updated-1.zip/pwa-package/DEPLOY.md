# Deploying this PWA, then regenerating the APK

## 1. Deploy the static site (pick one — both take about a minute)

**Netlify (drag-and-drop, no account setup needed beyond signup)**
1. Go to app.netlify.com/drop
2. Drag this whole `pwa-package` folder onto the page
3. Netlify gives you a URL like `https://random-name-123.netlify.app` — that's your HTTPS PWA URL

**Vercel**
1. Go to vercel.com/new
2. Import this folder (or push it to a GitHub repo first, then import that repo)
3. Deploy with default settings — `vercel.json` here already sets the right headers

Either way: once deployed, open the URL in a phone browser and confirm the
app loads and looks right before moving on.

## 2. Point the app at your real backend

Before or after building the APK, open the deployed URL → Account → Backend
Connection → paste your deployed backend's URL (from the `lscalpx-backend`
project) → Save. This is stored in the browser's local storage per install,
so you can also just do this once inside the built APK after installing it.

## 3. Regenerate the APK/AAB on PWABuilder

1. Go to pwabuilder.com, paste your deployed PWA URL
2. Let it score the manifest/service worker (should pass, both are already here)
3. Go to Android package → **Signing**: choose "Use existing key" and upload
   `signing.keystore` from your original package, entering the same
   passwords from `signing-key-info.txt`. Do **not** generate a new key —
   Google Play will treat a differently-signed build as a different app and
   reject the update.
4. Download the new APK/AAB.

## 4. Digital Asset Links (needed for passkeys + "no URL bar" TWA mode)

Your existing `assetlinks.json` needs to be served at
`https://<your-deployed-domain>/.well-known/assetlinks.json`. On Netlify/Vercel,
create a `.well-known/assetlinks.json` file in this folder with that content
before deploying (both hosts serve dotfolders fine). This is also what
`WEBAUTHN_ORIGIN` in the backend `.env` needs to match — same domain, `https://`.
